import HeroSection from './components/HeroSection'

function App() {
  return (
    <div className="bg-gray-900 text-white min-h-screen">
      <HeroSection />
    </div>
  )
}

export default App
